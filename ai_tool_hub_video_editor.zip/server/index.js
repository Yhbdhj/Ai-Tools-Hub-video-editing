import express from "express";
import cors from "cors";
import dotenv from "dotenv";
import OpenAI from "openai";
import Razorpay from "razorpay";
import crypto from "crypto";
import fs from "fs";
import path from "path";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";

dotenv.config();
const app = express();
app.use(cors({ origin: process.env.FRONTEND_URL || true }));
app.use(express.json({ limit: "10mb" }));

const DATA_DIR = path.resolve(process.env.DATA_DIR || "./data");
const USERS_FILE = path.join(DATA_DIR, "users.json");
fs.mkdirSync(DATA_DIR, { recursive: true });
if (!fs.existsSync(USERS_FILE)) fs.writeFileSync(USERS_FILE, "[]");
const readUsers = () => JSON.parse(fs.readFileSync(USERS_FILE, "utf8"));
const writeUsers = (users) => fs.writeFileSync(USERS_FILE, JSON.stringify(users, null, 2));

const openai = process.env.OPENAI_API_KEY ? new OpenAI({ apiKey: process.env.OPENAI_API_KEY }) : null;
const razorpay = process.env.RAZORPAY_KEY_ID && process.env.RAZORPAY_KEY_SECRET
  ? new Razorpay({ key_id: process.env.RAZORPAY_KEY_ID, key_secret: process.env.RAZORPAY_KEY_SECRET }) : null;
const JWT_SECRET = process.env.JWT_SECRET || "change-this-secret-before-production";

const plans = {
  pro_monthly: { amount: 39900, days: 30, tier: "pro" },
  pro_5_months: { amount: 129900, days: 150, tier: "pro" },
  premium_1_month: { amount: 59900, days: 30, tier: "premium" },
  premium_5_months: { amount: 199900, days: 150, tier: "premium" },
  premium_10_months: { amount: 359900, days: 300, tier: "premium" }
};

function tokenFor(user) { return jwt.sign({ id: user.id, email: user.email }, JWT_SECRET, { expiresIn: "30d" }); }
function auth(req, res, next) {
  const token = (req.headers.authorization || "").replace(/^Bearer\s+/i, "");
  try { req.user = jwt.verify(token, JWT_SECRET); next(); }
  catch { res.status(401).json({ error: "Please log in first." }); }
}

app.get("/api/health", (req,res)=>res.json({ ok:true, ai:!!openai, payments:!!razorpay, auth:true }));

app.post("/api/auth/signup", async (req,res)=>{
  try {
    const email = String(req.body?.email || "").trim().toLowerCase();
    const password = String(req.body?.password || "");
    if (!/^\S+@\S+\.\S+$/.test(email) || password.length < 6) return res.status(400).json({ error:"Use a valid email and a password of at least 6 characters." });
    const users = readUsers();
    if (users.some(u=>u.email===email)) return res.status(409).json({ error:"Account already exists. Please log in." });
    const user = { id: crypto.randomUUID(), email, passwordHash: await bcrypt.hash(password, 12), tier:"free", subscriptionUntil:null, createdAt:new Date().toISOString() };
    users.push(user); writeUsers(users);
    res.json({ token:tokenFor(user), user:{ id:user.id,email:user.email,tier:user.tier,subscriptionUntil:user.subscriptionUntil } });
  } catch(e) { res.status(500).json({ error:e.message || "Signup failed." }); }
});

app.post("/api/auth/login", async (req,res)=>{
  const email = String(req.body?.email || "").trim().toLowerCase();
  const password = String(req.body?.password || "");
  const user = readUsers().find(u=>u.email===email);
  if (!user || !(await bcrypt.compare(password, user.passwordHash))) return res.status(401).json({ error:"Invalid email or password." });
  res.json({ token:tokenFor(user), user:{ id:user.id,email:user.email,tier:user.tier,subscriptionUntil:user.subscriptionUntil } });
});

app.get("/api/auth/me", auth, (req,res)=>{
  const user = readUsers().find(u=>u.id===req.user.id);
  if (!user) return res.status(404).json({ error:"User not found." });
  res.json({ user:{ id:user.id,email:user.email,tier:user.tier,subscriptionUntil:user.subscriptionUntil } });
});

app.post("/api/ai/generate", async (req,res)=>{
  try {
    if (!openai) return res.status(503).json({ error:"OPENAI_API_KEY is not configured on the server." });
    const { tool, prompt } = req.body || {};
    if (!prompt?.trim()) return res.status(400).json({ error:"Prompt is required." });
    const response = await openai.responses.create({ model: process.env.OPENAI_TEXT_MODEL || "gpt-5.6-luna", input:`You are the AI engine for AI Tool Hub. Tool: ${tool || "AI Chat"}. Give useful, accurate, user-ready output. If this is a resume, cover letter, invitation, or other document, format it cleanly with headings. User request: ${prompt}` });
    res.json({ output: response.output_text || "No output generated." });
  } catch (e) { res.status(500).json({ error:e?.message || "AI request failed." }); }
});

app.post("/api/ai/invitation", async (req,res)=>{
  try {
    if (!openai) return res.status(503).json({ error:"OPENAI_API_KEY is not configured on the server." });
    const { type, details, quality="standard" } = req.body || {};
    if (!type || !details?.trim()) return res.status(400).json({ error:"Invitation type and details are required." });
    const response = await openai.responses.create({ model: process.env.OPENAI_TEXT_MODEL || "gpt-5.6-luna", input:`Create a polished ${type} invitation. Details: ${details}. Quality package: ${quality}. Return final invitation wording, an image-generation prompt, and typography/layout recommendations. Keep names, dates and venues exactly as supplied.` });
    res.json({ output: response.output_text || "No invitation generated." });
  } catch (e) { res.status(500).json({ error:e?.message || "Invitation request failed." }); }
});

app.post("/api/ai/image", async (req,res)=>{
  try {
    if (!openai) return res.status(503).json({ error:"OPENAI_API_KEY is not configured on the server." });
    const { prompt, quality="medium", size="1024x1024" } = req.body || {};
    if (!prompt?.trim()) return res.status(400).json({ error:"Image prompt is required." });
    const image = await openai.images.generate({ model: process.env.OPENAI_IMAGE_MODEL || "gpt-image-2", prompt, quality, size });
    const b64 = image?.data?.[0]?.b64_json;
    if (!b64) return res.status(502).json({ error:"Image provider returned no image data." });
    res.json({ image:`data:image/png;base64,${b64}` });
  } catch (e) { res.status(500).json({ error:e?.message || "Image generation failed." }); }
});

app.post("/api/payments/order", auth, async (req,res)=>{
  try {
    if (!razorpay) return res.status(503).json({ error:"Razorpay credentials are not configured on the server." });
    const planId = req.body?.plan;
    const plan = plans[planId];
    if (!plan) return res.status(400).json({ error:"Invalid plan." });
    const order = await razorpay.orders.create({ amount:plan.amount, currency:"INR", receipt:`hub_${Date.now()}`, notes:{ plan:planId, userId:req.user.id } });
    res.json({ id:order.id, amount:order.amount, currency:order.currency, keyId:process.env.RAZORPAY_KEY_ID, plan:planId });
  } catch (e) { res.status(500).json({ error:e?.message || "Could not create payment order." }); }
});

app.post("/api/payments/verify", auth, (req,res)=>{
  try {
    if (!process.env.RAZORPAY_KEY_SECRET) return res.status(503).json({ error:"Razorpay secret is not configured." });
    const { razorpay_order_id, razorpay_payment_id, razorpay_signature, plan } = req.body || {};
    if (!plans[plan]) return res.status(400).json({ verified:false, error:"Invalid plan." });
    const expected = crypto.createHmac("sha256", process.env.RAZORPAY_KEY_SECRET).update(`${razorpay_order_id}|${razorpay_payment_id}`).digest("hex");
    const valid = typeof razorpay_signature === "string" && razorpay_signature.length === expected.length && crypto.timingSafeEqual(Buffer.from(expected), Buffer.from(razorpay_signature));
    if (!valid) return res.json({ verified:false });
    const users = readUsers(); const idx = users.findIndex(u=>u.id===req.user.id);
    if (idx<0) return res.status(404).json({ verified:false, error:"User not found." });
    const p = plans[plan];
    const base = Math.max(Date.now(), users[idx].subscriptionUntil ? new Date(users[idx].subscriptionUntil).getTime() : 0);
    users[idx].tier = p.tier;
    users[idx].subscriptionUntil = new Date(base + p.days*86400000).toISOString();
    users[idx].lastPaymentId = razorpay_payment_id;
    users[idx].lastPlan = plan;
    writeUsers(users);
    res.json({ verified:true, tier:users[idx].tier, subscriptionUntil:users[idx].subscriptionUntil });
  } catch { res.status(400).json({ verified:false }); }
});

const port = Number(process.env.PORT || 5000);
app.listen(port, ()=>console.log(`AI Tool Hub API running on http://localhost:${port}`));
