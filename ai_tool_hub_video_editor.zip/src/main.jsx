
import React,{useState,useRef,useEffect} from "react";

const API_URL=import.meta.env.VITE_API_URL || "http://localhost:5000";
import {createRoot} from "react-dom/client";
import "./style.css";

const tools=[
 ["🤖","AI Chat","Ask anything and get an AI answer.","chat"],
 ["📄","Resume Builder","Create a professional resume.","resume"],
 ["💼","Cover Letter","Generate a job-specific cover letter.","cover"],
 ["🎤","Interview Prep","Generate interview questions.","interview"],
 ["✍️","AI Writer","Create blogs, emails and social posts.","writer"],
 ["📝","Summarizer","Summarize long text quickly.","summary"],
 ["🎬","Video Editor","Trim, change speed, mute audio and export your video.","video"],
 ["💍","Wedding Invitation","Create elegant wedding invitation cards with AI.","wedding"],
 ["💐","Engagement Invitation","Create beautiful engagement invitation cards.","engagement"],
 ["🎂","Birthday Invitation","Create fun or elegant birthday party invitations.","birthday"],
 ["🎉","Party Invitation","Create invitations for parties and celebrations.","party"]
];

const invitationPackages=[
 {name:"Wedding Invitation",icon:"💍",desc:"AI-designed wedding cards for WhatsApp, Instagram and print.",plans:[["Basic","₹99","Clean design • 1 concept • HD"],["Standard","₹199","Premium design • 2 concepts • Full HD"],["Luxury","₹399","Luxury design • 3 concepts • 4K export"]]},
 {name:"Engagement Invitation",icon:"💐",desc:"Stylish engagement invitations with modern and traditional themes.",plans:[["Basic","₹99","Clean design • 1 concept • HD"],["Standard","₹199","Premium design • 2 concepts • Full HD"],["Luxury","₹399","Luxury design • 3 concepts • 4K export"]]},
 {name:"Birthday Invitation",icon:"🎂",desc:"Personalized birthday invitations for kids, teens and adults.",plans:[["Basic","₹79","Simple design • 1 concept • HD"],["Standard","₹149","Creative design • 2 concepts • Full HD"],["Premium","₹299","Premium design • 3 concepts • 4K export"]]},
 {name:"Party Invitation",icon:"🎉",desc:"Fun invitation cards for parties, anniversaries and celebrations.",plans:[["Basic","₹79","Simple design • 1 concept • HD"],["Standard","₹149","Creative design • 2 concepts • Full HD"],["Premium","₹299","Premium design • 3 concepts • 4K export"]]}
];


function VideoEditorModal({onClose}){
 const videoRef=useRef(null),recRef=useRef(null),streamRef=useRef(null),chunksRef=useRef([]),urlRef=useRef(null);
 const [file,setFile]=useState(null),[src,setSrc]=useState(""),[duration,setDuration]=useState(0),[start,setStart]=useState(0),[end,setEnd]=useState(0),[speed,setSpeed]=useState(1),[mute,setMute]=useState(false),[status,setStatus]=useState(""),[busy,setBusy]=useState(false),[downloadUrl,setDownloadUrl]=useState("");
 useEffect(()=>()=>{if(src)URL.revokeObjectURL(src); if(downloadUrl)URL.revokeObjectURL(downloadUrl); if(streamRef.current)streamRef.current.getTracks().forEach(t=>t.stop());},[src,downloadUrl]);
 const loadFile=e=>{
   const f=e.target.files?.[0]; if(!f) return;
   if(!f.type.startsWith("video/")){setStatus("Please select a video file.");return;}
   if(src)URL.revokeObjectURL(src); if(downloadUrl)URL.revokeObjectURL(downloadUrl);
   const u=URL.createObjectURL(f); setFile(f);setSrc(u);setDuration(0);setStart(0);setEnd(0);setDownloadUrl("");setStatus("");
 };
 const loaded=()=>{const d=videoRef.current?.duration||0;setDuration(d);setEnd(d);videoRef.current.playbackRate=speed;videoRef.current.muted=mute;};
 const preview=async()=>{
   if(!videoRef.current) return; const v=videoRef.current; const s=Math.max(0,Math.min(Number(start)||0,duration)); const e=Math.max(s+0.1,Math.min(Number(end)||duration,duration));
   v.currentTime=s;v.playbackRate=Number(speed);v.muted=mute;setStatus("Preview playing…");
   try{await v.play();}catch{};
   const stop=()=>{if(v.currentTime>=e-0.05){v.pause();v.removeEventListener("timeupdate",stop);setStatus("Preview finished.");}};v.addEventListener("timeupdate",stop);
 };
 const exportVideo=async()=>{
   if(!videoRef.current||!file||!duration){setStatus("Choose a video first.");return;}
   const v=videoRef.current; const s=Math.max(0,Math.min(Number(start)||0,duration)); const e=Math.max(s+0.1,Math.min(Number(end)||duration,duration));
   const capture=v.captureStream?.bind(v); if(!capture){setStatus("This browser does not support video export. Try Chrome on Android or desktop Chrome.");return;}
   setBusy(true);setStatus("Exporting edited video… keep this window open.");setDownloadUrl("");
   try{
     if(streamRef.current)streamRef.current.getTracks().forEach(t=>t.stop());
     v.currentTime=s;v.playbackRate=Number(speed);v.muted=mute;
     if(Math.abs(v.currentTime-s)>0.05){await new Promise(r=>{const fn=()=>{v.removeEventListener("seeked",fn);r()};v.addEventListener("seeked",fn)});}
     const stream=capture();streamRef.current=stream;
     const mime=MediaRecorder.isTypeSupported("video/webm;codecs=vp9,opus")?"video/webm;codecs=vp9,opus":MediaRecorder.isTypeSupported("video/webm")?"video/webm":"";
     if(!mime)throw new Error("WebM recording is not supported in this browser.");
     const rec=new MediaRecorder(stream,{mimeType:mime});recRef.current=rec;chunksRef.current=[];
     rec.ondataavailable=e=>{if(e.data.size)chunksRef.current.push(e.data)};
     const done=new Promise((resolve,reject)=>{rec.onstop=resolve;rec.onerror=()=>reject(new Error("Recording failed"))});
     rec.start(250);await v.play();
     await new Promise((resolve)=>{const check=()=>{if(v.currentTime>=e-0.05){v.pause();resolve()}else requestAnimationFrame(check)};check()});
     rec.stop();await done;stream.getTracks().forEach(t=>t.stop());
     const blob=new Blob(chunksRef.current,{type:"video/webm"});const u=URL.createObjectURL(blob);setDownloadUrl(u);setStatus("Done! Tap Download edited video.");
   }catch(err){setStatus(`Export failed: ${err.message}`)}finally{setBusy(false)}
 };
 return <div className="overlay"><div className="modal videoModal"><button className="close" onClick={onClose}>×</button><div className="modalIcon">🎬</div><h2>Video Editor</h2><p>Upload a video, trim it, change speed or mute audio, then export the edited clip.</p><input type="file" accept="video/*" onChange={loadFile}/>{src&&<video ref={videoRef} src={src} controls className="videoPreview" onLoadedMetadata={loaded}/>} {file&&<div className="videoControls"><label>Start <input type="number" min="0" max={duration||0} step="0.1" value={start} onChange={e=>setStart(e.target.value)}/></label><label>End <input type="number" min="0.1" max={duration||0} step="0.1" value={end} onChange={e=>setEnd(e.target.value)}/></label><label>Speed <select value={speed} onChange={e=>{setSpeed(Number(e.target.value));if(videoRef.current)videoRef.current.playbackRate=Number(e.target.value)}}><option value="0.5">0.5×</option><option value="0.75">0.75×</option><option value="1">1×</option><option value="1.25">1.25×</option><option value="1.5">1.5×</option><option value="2">2×</option></select></label><label className="check"><input type="checkbox" checked={mute} onChange={e=>{setMute(e.target.checked);if(videoRef.current)videoRef.current.muted=e.target.checked}}/> Mute audio</label></div>}{file&&<div className="videoActions"><button className="secondary" onClick={preview}>Preview edit</button><button className="primary" onClick={exportVideo} disabled={busy}>{busy?"Exporting…":"Export edited video"}</button></div>}{downloadUrl&&<a className="downloadBtn" href={downloadUrl} download={`ai-tool-hub-edited-${file?.name?.replace(/\.[^.]+$/,"")||"video"}.webm`}>⬇ Download edited video</a>}{status&&<p className="muted">{status}</p>}<small className="muted">Editing happens in your browser. Export is WebM; no video is uploaded by this basic editor.</small></div></div>
}

function ToolModal({tool,onClose}){
 const [input,setInput]=useState("");
 const [out,setOut]=useState("");
 const [busy,setBusy]=useState(false);
 const generate=async()=>{
   if(!input.trim()) return;
   setBusy(true); setOut("");
   try{
     if(["wedding","engagement","birthday","party"].includes(tool[3])){
       const briefRes=await fetch(`${API_URL}/api/ai/invitation`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({type:tool[1],details:input,quality:"premium"})});
       const brief=await briefRes.json(); if(!briefRes.ok) throw new Error(brief.error||"Invitation generation failed");
       setOut(brief.output);
       const imageRes=await fetch(`${API_URL}/api/ai/image`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({prompt:`Create a premium ${tool[1]} invitation card. Use this exact event information and wording where possible: ${input}. Design brief: ${brief.output}. Elegant, readable typography, polished Indian celebration aesthetic, print-ready composition.`,quality:"high",size:"1024x1024"})});
       const image=await imageRes.json(); if(imageRes.ok && image.image) setOut(prev=>prev+"\n\n[AI IMAGE GENERATED]\n"+image.image); else if(!imageRes.ok) setOut(prev=>prev+"\n\nImage generation: "+(image.error||"failed"));
     } else {
       const r=await fetch(`${API_URL}/api/ai/generate`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({tool:tool[1],prompt:input})});
       const data=await r.json();
       if(!r.ok) throw new Error(data.error||"AI request failed");
       setOut(data.output);
     }
   }catch(e){setOut(`Connection error: ${e.message}\n\nStart the backend and add your API key in server/.env.`);}
   finally{setBusy(false);}
 };
 return <div className="overlay"><div className="modal"><button className="close" onClick={onClose}>×</button><div className="modalIcon">{tool[0]}</div><h2>{tool[1]}</h2><p>{tool[2]}</p><textarea value={input} onChange={e=>setInput(e.target.value)} placeholder={tool[1]==="Resume Builder"?"Enter your name, education, skills and experience...":"Enter your request here..."}/><button className="primary full" onClick={generate} disabled={busy}>{busy?"Generating…":"Generate with AI"}</button>{out&&<pre className="output">{out}</pre>}</div></div>
}

function AuthModal({onClose,onLogin}){
 const [mode,setMode]=useState("login"); const [email,setEmail]=useState(""); const [password,setPassword]=useState(""); const [busy,setBusy]=useState(false); const [error,setError]=useState("");
 const submit=async()=>{setBusy(true);setError("");try{const r=await fetch(`${API_URL}/api/auth/${mode}`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({email,password})});const d=await r.json();if(!r.ok)throw new Error(d.error||"Authentication failed");localStorage.setItem("ath_token",d.token);onLogin(d.user,d.token);onClose();}catch(e){setError(e.message)}finally{setBusy(false)}};
 return <div className="overlay"><div className="modal auth"><button className="close" onClick={onClose}>×</button><h2>{mode==="login"?"Welcome back":"Create your account"}</h2><input value={email} onChange={e=>setEmail(e.target.value)} placeholder="Email" type="email"/><input value={password} onChange={e=>setPassword(e.target.value)} placeholder="Password (6+ characters)" type="password"/>{error&&<p className="error">{error}</p>}<button className="primary full" onClick={submit} disabled={busy}>{busy?"Please wait…":mode==="login"?"Log in":"Sign up"}</button><button className="secondary full" onClick={()=>setMode(mode==="login"?"signup":"login")}>{mode==="login"?"Create new account":"I already have an account"}</button></div></div>
}

function PaymentModal({onClose,token,onPaid}){
 const [plan,setPlan]=useState("premium_1_month"); const [busy,setBusy]=useState(false);
 const pay=async()=>{setBusy(true);try{const r=await fetch(`${API_URL}/api/payments/order`,{method:"POST",headers:{"Content-Type":"application/json","Authorization":`Bearer ${token}`},body:JSON.stringify({plan})});const order=await r.json();if(!r.ok)throw new Error(order.error||"Order creation failed");if(!window.Razorpay)throw new Error("Razorpay Checkout script is not loaded.");const rz=new window.Razorpay({key:order.keyId,amount:order.amount,currency:order.currency,name:"AI Tool Hub",description:"AI Tool Hub plan",order_id:order.id,handler:async response=>{const vr=await fetch(`${API_URL}/api/payments/verify`,{method:"POST",headers:{"Content-Type":"application/json","Authorization":`Bearer ${token}`},body:JSON.stringify({...response,plan})});const vd=await vr.json();alert(vd.verified?"Payment verified successfully!":"Payment verification failed.");if(vd.verified){onPaid(vd);onClose();}}});rz.open();}catch(e){alert(e.message)}finally{setBusy(false)}};
 return <div className="overlay"><div className="modal"><button className="close" onClick={onClose}>×</button><h2>Choose your plan</h2><select value={plan} onChange={e=>setPlan(e.target.value)}><option value="pro_monthly">Pro — ₹399 / month</option><option value="pro_5_months">Pro — ₹1299 / 5 months</option><option value="premium_1_month">Premium — ₹599 / 1 month</option><option value="premium_5_months">Premium — ₹1999 / 5 months</option><option value="premium_10_months">Premium — ₹3599 / 10 months</option></select><button className="primary full" onClick={pay} disabled={busy}>{busy?"Creating order…":"Pay securely with Razorpay"}</button><p className="muted">Razorpay secret stays on the backend. Use test keys while developing.</p></div></div>
}

function App(){
 const [selected,setSelected]=useState(null),[auth,setAuth]=useState(false),[pro,setPro]=useState(false),[user,setUser]=useState(null),[token,setToken]=useState(localStorage.getItem("ath_token")||"");
 React.useEffect(()=>{if(token)fetch(`${API_URL}/api/auth/me`,{headers:{Authorization:`Bearer ${token}`}}).then(r=>r.ok?r.json():Promise.reject()).then(d=>setUser(d.user)).catch(()=>{localStorage.removeItem("ath_token");setToken("")})},[]);
 const login=(u,t)=>{setUser(u);setToken(t)}; const logout=()=>{localStorage.removeItem("ath_token");setToken("");setUser(null)};
 const buy=()=>{if(!token){setAuth(true);return}setPro(true)};
 return <div>
  <header><div className="logo">✦ AI Tool Hub</div><nav><a href="#tools">Tools</a><a href="#pricing">Pricing</a>{user?<><span className="count">{user.tier.toUpperCase()}</span><button className="login" onClick={logout}>Logout</button></>:<button className="login" onClick={()=>setAuth(true)}>Login / Sign up</button>}</nav></header>
  <section className="hero"><div className="badge">✨ AI tools for smarter work</div><h1>Create more with <span>Artificial Intelligence</span></h1><p>Chat, write, build resumes, create invitation cards and prepare for interviews from one simple platform.</p><div className="actions"><button className="primary" onClick={()=>document.getElementById("tools").scrollIntoView({behavior:"smooth"})}>Explore AI Tools →</button><button className="secondary" onClick={()=>document.getElementById("pricing").scrollIntoView({behavior:"smooth"})}>Go Pro</button></div></section>
  <section id="tools" className="section"><div className="sectionHead"><div><p className="eyebrow">AI TOOLKIT</p><h2>Popular AI Tools</h2></div><span className="count">{tools.length} tools</span></div><div className="grid">{tools.map((t,i)=><div className="card" key={i}><div className="icon">{t[0]}</div><h3>{t[1]}</h3><p>{t[2]}</p><button onClick={()=>setSelected(t)}>Open Tool →</button></div>)}</div></section>
  <section className="invites section"><div className="sectionHead"><div><p className="eyebrow">AI INVITATION STUDIO</p><h2>Create Invitation Cards</h2><p className="sectionIntro">Wedding, engagement, birthday and party invitations with different design-quality packages.</p></div><span className="count">4 categories</span></div><div className="inviteGrid">{invitationPackages.map((item,i)=><div className="inviteCard" key={i}><div className="inviteTop"><div className="inviteIcon">{item.icon}</div><div><h3>{item.name}</h3><p>{item.desc}</p></div></div><div className="qualityPlans">{item.plans.map((plan,j)=><div className={"qualityPlan "+(j===2?"best":"")} key={j}><span className="qualityName">{plan[0]}</span><strong>{plan[1]}</strong><small>{plan[2]}</small><button onClick={()=>setSelected([item.icon,item.name,"Create your invitation details",item.name.toLowerCase().split(" ")[0]])}>Create Now</button></div>)}</div></div>)}</div></section>
  <section className="dashboard"><div><p className="eyebrow">YOUR WORKSPACE</p><h2>One dashboard for your AI work</h2><p>Real account login and paid-plan status are stored by the backend.</p></div><div className="dashbox"><b>{user?`${user.email} • ${user.tier.toUpperCase()}`:"Free plan"}</b><span>{user?.subscriptionUntil?`Active until ${new Date(user.subscriptionUntil).toLocaleDateString()}`:"5 generations / day demo limit"}</span><button onClick={buy}>Upgrade to Pro</button></div></section>
  <section id="pricing" className="pricing"><p className="eyebrow">PRICING</p><h2>Simple plans for everyone</h2><div className="plans"><div className="plan"><h3>Free</h3><strong>₹0</strong><p>5 generations/day<br/>Core AI tools<br/>Basic support</p><button>Current Plan</button></div><div className="plan featured"><div className="popular">POPULAR</div><h3>Pro Monthly</h3><strong>₹399<span>/month</span></strong><p>Higher usage limits<br/>All AI tools<br/>Priority access</p><button onClick={buy}>Choose Monthly</button></div><div className="plan featured five"><div className="popular">5 MONTHS</div><h3>Pro 5 Months</h3><strong>₹1299<span>/5 months</span></strong><p>Higher usage limits<br/>All AI tools<br/>Priority access</p><button onClick={buy}>Choose 5 Months</button></div><div className="plan premium"><div className="premiumBadge">PREMIUM</div><h3>Premium AI</h3><div className="premiumPrices"><strong>₹599<span>/1 month</span></strong><strong>₹1999<span>/5 months</span></strong><strong>₹3599<span>/10 months</span></strong></div><p>High-quality image editing<br/>AI presentation creator<br/>AI video creator<br/>AI file/document creator</p><button onClick={buy}>Choose Premium</button></div></div><small className="note">Live AI and Razorpay require your own provider credentials in server/.env.</small></section>
  <footer><b>✦ AI Tool Hub</b><span>© 2026 AI Tool Hub</span></footer>
  {selected&& (selected[3]==="video" ? <VideoEditorModal onClose={()=>setSelected(null)}/> : <ToolModal tool={selected} onClose={()=>setSelected(null)}/>) } {auth&&<AuthModal onClose={()=>setAuth(false)} onLogin={login}/>} {pro&&<PaymentModal token={token} onClose={()=>setPro(false)} onPaid={(d)=>setUser(u=>({...u,tier:d.tier,subscriptionUntil:d.subscriptionUntil}))}/>
 </div>
}

createRoot(document.getElementById("root")).render(<App/>);
